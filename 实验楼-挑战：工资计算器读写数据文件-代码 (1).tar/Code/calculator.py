#!/usr/bin/env python3
import sys
import os
import csv


class Args:
    def __init__(self):
        self.args = sys.argv
        
    def getc(self):
        try:
            i = self.args.index('-c')
            path = self.args[i+1]
            if self.check(path):
                return path
            else:
                self.warn()
        except Exception :
            self.warn()
        
    def check(self, path):
        if path:
            if os.path.isfile(path):
                return True
            else:
                print('{} is not exists.'.format(path))

    def getd(self):
        try:
            i = self.args.index('-d')
            path = self.args[i+1]
            if self.check(path):
                return path
            else:
                self.warn()
        except Exception :
            self.warn()
    
    def geto(self):
        try:
            i = self.args.index('-o')
            path = self.args[i+1]
            if self.check(path):
                return path
            else:
                self.warn()
        except Exception :
            self.warn()
        
    def warn(self):
        print("Parameter Error.")
        print("{} -c <confile> -d <userfile> -o <savefile>".format(self.args[0]))
        sys.exit(-1)

    
    
class Config:
    
    def __init__(self, filename):
        self.config = self._read_config(filename)

    def _read_config(self, cfgfile):
        config = {}
        with open(cfgfile) as f:
            for line in f:
                k, v = line.split('=')
                k = k.strip()
                try:
                    v = float(v.strip())
                    config[k] = v
                except Exception as e:
                    print(e)
                    return
            return config



class UserData:
    def __init__(self, filename):
        self.userdata = self._read_users_data(filename)


    def _read_users_data(self, datafile):
        userdata = {}
        with open(datafile) as f:
            t = tuple(csv.reader(f))
            for i in t:
                try:
                    k, v = i
                    userdata[k] = int(v)
                except Exception as e:
                    print(e)
                    return
            return userdata

class IncomeTaxCalculator:
    def calc_for_all_userdata(self, userdata, cfgdata):
        result = []
        tax_rate = sum(cfgdata.values()[2:])
        for k, v in userdata:
            tmp = []
            tmp.append(k)
            tmp.append(v)
            
            jishul = cfgdata['JiShuL']
            jishuh = cfgdata['JiShuH']

            if v <= 0:
                taxbase = 0
            elif v <  jishul:
                taxbase = jishul
            elif v < jishuh:
                taxbase = v
            else:
                taxbase = jishuh

            tax = taxbase * tax_rate
            tmp.append(tax)
            



        
        reurn result


    def export(self, filename='out.csv'):
        result = self.calc_for_all_userdata()
        with open(filename) as f:
            csv.writer(f).writerows(result)







if __name__ == '__main__':
    args = Args()
    print(args.getc(), args.getd(), args.geto())
